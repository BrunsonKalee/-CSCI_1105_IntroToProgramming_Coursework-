package ch42_37;

import static org.junit.Assert.*;

import org.junit.Test;

public class SpecifiedWidthTest {

	@Test
	public void testformat() {
		assertEquals(SpecifiedWidth.format(34, 4), "0034");
		assertEquals(SpecifiedWidth.format(34, 5), "00034");
	}

}
